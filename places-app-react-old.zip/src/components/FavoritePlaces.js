import React, {useState, useEffect} from 'react';
import { connect } from 'react-redux';
// import { Link } from 'react-router-dom';
import Loader from './Loader';

const FavoritePlaces = (props) => {
  const {myFavorities, myPlacesList} = props;
  console.log(props, myFavorities);

  const [favoritiesData, setFavoritiesData] = useState([]);

  useEffect(() => {
    let myFavPlacesId = myFavorities; 
    let filterdFavData = [];
    myPlacesList.map(ele => myFavPlacesId.includes(ele.id) ? filterdFavData.push(ele) : filterdFavData)
    setFavoritiesData(filterdFavData);
  }, [myFavorities, myPlacesList])

  console.log("favoritiesData", favoritiesData);
  return (
    <div className="container-fluid">
      <div className="title text-center">
        <h1>List of Favorities</h1>
      </div>
      <div className="row">

        {
          favoritiesData.length > 0 ? (
            favoritiesData.map(p => {
              return (
                <div className="col-lg-4" key={p.id}>
                  <div className="card mb-30">
                    <div className="card-body">
                      <h4 className="card-title">{p.name}</h4>
                      <p className="card-text">
                        {p.official_description &&
                          (p.official_description).charAt(0).toUpperCase()
                          + (p.official_description).slice(1, 120)}...</p>
                      {/* <Link to={{ pathname: `/placeDetails/${p.id}`, state: p.id }} className="card-link btn btn-sm btn-info">View More</Link>
                      <p className="favorite float-right" onClick={() => favoriteHandler(p.id)}><i className={p.isFavorite ? "fas fa-heart new-color" : "fas fa-heart old-color"}></i></p> */}
                    </div>
                  </div>
                </div>
              )
            })
          ) : (favoritiesData.length===0?(
            <p>No data found</p>
          ):(<Loader loaderText="Loading myFavorities" />) )

        }
      </div>
    </div>
  )
}
const mapStateToProps = (state) => {
  return {
    myFavorities : state.myFavorities,
    myPlacesList : state.myPlacesList
  }
}

export default connect(mapStateToProps, null)(FavoritePlaces);