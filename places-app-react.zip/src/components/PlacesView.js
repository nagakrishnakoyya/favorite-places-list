import React, { useState, useEffect } from 'react';
import { placesBaseUrl } from '../contants.config';
import Loader from './Loader';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { myFavoritePlaces, myPlacesList } from '../store/favorite.action';
import { getPlacesData, updateLatestPlaces } from '../store/placesLoading.action';

const PlacesView = (props) => {
  const {getPlaces, placesList} = props;
  console.log("props", props);
  console.log("placesList", placesList);
  const [places, setPlaces] = useState([]);
  const [favoriteItems, setFavoriteItems] = useState([]);

  useEffect(() => {
    getPlaces();
    // getPlacesData();
  }, [getPlaces]);

  // const getPlacesData = () => {
  //   const apiEndpoint = "places";
  //   fetch(`${placesBaseUrl}/${apiEndpoint}`)
  //     .then(res => res.json())
  //     .then(data => {
  //       // const dataList = data.places.map(item=>item.isFavorite=false);
  //       setPlaces(data.places);
  //       // console.log(data.places);
  //     })
  //     .catch(error => {
  //       console.log(error);
  //     })
  // }

  const favoriteHandler = (id) => {
    const myPlaces = [...placesList];
    const itemIndex = placesList.findIndex(item => item.id === id);
    if (myPlaces[itemIndex].isFavorite) {
      myPlaces[itemIndex].isFavorite = false;
      const favoriteItemIndex = favoriteItems.indexOf(id);
      favoriteItems.splice(favoriteItemIndex, 1);
    } else {
      myPlaces[itemIndex].isFavorite = true;
      setFavoriteItems([...favoriteItems, id]);
    }
    // setPlaces(myPlaces);
    props.myFavList(favoriteItems);
    props.myPlaces(myPlaces);
  }

  // console.log("places", places);
  return (
    <div className="container-fluid">
      <div className="title text-center">
        <h1>List of Places</h1>
      </div>
      <div className="row">

        {
          placesList.length > 0 ? (
            placesList.map(p => {
              return (
                <div className="col-lg-4" key={p.id}>
                  <div className="card mb-30">
                    <div className="card-body">
                      <h4 className="card-title">{p.name}{p.id}</h4>
                      <p className="card-text">
                        {p.official_description &&
                          (p.official_description).charAt(0).toUpperCase()
                          + (p.official_description).slice(1, 120)}...</p>
                      <Link to={{ pathname: `/placeDetails/${p.id}`, state: p.id }} className="card-link btn btn-sm btn-info">View More</Link>
                      <p className="favorite float-right" onClick={() => favoriteHandler(p.id)}><i className={p.isFavorite ? "fas fa-heart new-color" : "fas fa-heart old-color"}></i></p>
                    </div>
                  </div>
                </div>
              )
            })
          ) : (
              <Loader loaderText="Loading places" />
            )

        }
      </div>
    </div>
  )
}

const mapStateToProps = (state) => {
  console.log("state", state);
  return {
    placesList : state.placesLoadingReducer.myPlacesList
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    getPlaces: () => { dispatch(getPlacesData()) },
    myFavList: (favoriteItems) => { dispatch(myFavoritePlaces(favoriteItems)) },
    myPlaces: (places) => { dispatch(updateLatestPlaces(places)) },
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(PlacesView);