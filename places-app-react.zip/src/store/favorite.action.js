export const LISTOFFAVORITES = 'LISTOFFAVORITES';
export const LISTOFPLACES = 'LISTOFPLACES';

export const myFavoritePlaces=(favorities)=>{
  return{
    type : LISTOFFAVORITES,
    favorities
  }
}

export const myPlacesList=(places)=>{
  return{
    type : LISTOFPLACES,
    places
  }
}
