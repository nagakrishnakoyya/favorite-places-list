import * as actionTypes from './favorite.action';

const initialState = {
  myFavorities:'',
  myPlacesList:[],
}
export const favoriteReducer=(state=initialState, action)=>{
  switch(action.type){
    case actionTypes.LISTOFFAVORITES:
      return {
        ...state,
        myFavorities:action.favorities
      }
    case actionTypes.LISTOFPLACES:
      return {
        ...state,
        myPlacesList:action.places
      }
      default:
        return state;
  }
}