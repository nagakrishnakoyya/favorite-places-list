import {placesBaseUrl} from '../contants.config';

export const LOAD_PLACES_PENDING = 'LOAD_PLACES_PENDING';
export const LOAD_PLACES_SUCCESS = 'LOAD_PLACES_SUCCESS';
export const LOAD_PLACES_ERROR = 'LOAD_PLACES_ERROR';
export const UPDATE_PLACES = 'UPDATE_PLACES';



export const loadPlacesPending = (isPending) => {
  return {
    type: LOAD_PLACES_PENDING,
    payload: isPending
  }
}

export const loadPlacesSuccess = (data) => {
  return {
    type: LOAD_PLACES_SUCCESS,
    payload: data
  }
}

export const loadPlacesError = (error) => {
  return {
    type: LOAD_PLACES_ERROR,
    payload: error
  }
}

export const updateLatestPlaces = (data) => {
  return {
    type: UPDATE_PLACES,
    payload : data
  }
}

// Getting Products

export const getPlacesData = () => {
  return (dispatch) => {
    dispatch(loadPlacesPending(true));
    const apiEndpoint = "places";
    fetch(`${placesBaseUrl}/${apiEndpoint}`)
      .then(res => res.json())
      .then(data => {
        console.log(data);
        dispatch(loadPlacesPending(false));
        dispatch(loadPlacesSuccess(data.places));
      })
      .catch(error => {
        dispatch(loadPlacesPending(false));
        dispatch(loadPlacesError(error));
      })
  }
}