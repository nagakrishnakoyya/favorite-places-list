import * as actionTypes from './placesLoading.action';

const initialState = {
  myPlacesList:[],
  loading: false,
  error: null,
}
export const placesLoadingReducer=(state=initialState, action)=>{
  switch (action.type) {
    case actionTypes.LOAD_PLACES_PENDING:
      return {
        ...state,
        loading: action.payload,
      }
    case actionTypes.LOAD_PLACES_SUCCESS:
      return {
        ...state,
        myPlacesList: action.payload,

      }
    case actionTypes.LOAD_PLACES_ERROR:
      return {
        ...state,
        error: action.payload,
      }
    case actionTypes.UPDATE_PLACES:
      return {
        ...state,
        myPlacesList: action.payload,
      }

    default:
      return state;
  }

  // switch(action.type){
  //   case actionTypes.UPDATE_PLACES:
  //     return {
  //       ...state,
  //       myPlacesList:action.data
  //     }
  //     default:
  //       return state;
  // }
}