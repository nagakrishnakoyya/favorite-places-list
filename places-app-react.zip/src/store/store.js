import {createStore, applyMiddleware, combineReducers} from 'redux';
import thunk from 'redux-thunk';
import {favoriteReducer} from './favorite.reducer';
import {placesLoadingReducer} from './placesLoading.reducer';

const rootReducer = combineReducers({
  favoriteReducer,
  placesLoadingReducer
});

export const store = createStore(rootReducer, applyMiddleware(thunk));